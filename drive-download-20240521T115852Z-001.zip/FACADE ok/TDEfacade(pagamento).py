import sys

class PaymentFacade:
    def __init__(self):
        self.credit_card_processor = CreditCardProcessor()
        self.paypal_processor = PayPalProcessor()
        self.debit_processor = DebitProcessor()

    def process_payment(self, amount, method):
        if method == "credit_card":
           
           
            return self.credit_card_processor.process_payment
        elif method == "paypal":
            
            return self.paypal_processor.process_payment
        elif method == "debit": 
            return self.debit_processor.process_payment
        else:
            print("Método de pagamento inválido.")
            return False

class CreditCardProcessor:
    def process_payment(self, amount, card_number, cvv, expiration_date):
        print(f"Processando pagamento de ${amount} com cartão de crédito...")
        # Lógica para processar o pagamento com cartão de crédito
        # Retorna True se o pagamento for bem-sucedido, False caso contrário
        return True

class PayPalProcessor:
    def process_payment(self, amount, email, password):
        print(f"Processando pagamento de ${amount} com PayPal...")
        # Lógica para processar o pagamento com PayPal
        # Retorna True se o pagamento for bem-sucedido, False caso contrário
        return True

class DebitProcessor:
    def process_payment(self, amount):
        print(f"Processando pagamento de ${amount} com cartão de débito...")
        # Lógica para processar o pagamento com cartão de débito
        # Retorna True se o pagamento for bem-sucedido, False caso contrário
        return True

# Exemplo de uso
if __name__ == "__main__":
    amount = float(input("Informe o valor do pagamento: ").replace(',', '.'))
    payment_method = input("Escolha o método de pagamento (credit_card, paypal, debit): ")
    
    payment_facade = PaymentFacade()
    success = payment_facade.process_payment(amount, payment_method)
    if success:
        print("Pagamento processado com sucesso!")
    else:
        print("Falha ao processar o pagamento. Verifique os detalhes e tente novamente.")

    # Encerrar o programa imediatamente
    sys.exit()
