class DVDPlayer:
    def on(self):
        print("DVD Player LIGADO")
    
    def play(self, movie):
        print(f"Reproduzindo filme: {movie}")
    
    def off(self):
        print("DVD Player DESLIGADO")

class Amplifier:
    def on(self):
        print("Amplificador LIGADO")
    
    def set_volume(self, level):
        print(f"Volume do amplificador ajustado para {level}")
    
    def off(self):
        print("Amplificador DESLIGADO")

class Lights:
    def dim(self, level):
        print(f"Luzes reduzidas para {level}%")

    def on(self):
        print("Luzes LIGADAS")
    
    def off(self):
        print("Luzes DESLIGADAS")

class HomeTheaterFacade:
    def __init__(self, dvd: DVDPlayer, amp: Amplifier, lights: Lights):
        self.dvd = dvd
        self.amp = amp
        self.lights = lights

    def assistir_filme(self, movie):
        print("Preparando para assistir a um filme...")
        self.lights.dim(10)
        self.amp.on()
        self.amp.set_volume(5)
        self.dvd.on()
        self.dvd.play(movie)

    def encerrar_filme(self):
        print("Encerrando filme")
        self.dvd.off()
        self.amp.off()
        self.lights.on()

# Subsistemas
dvd_player = DVDPlayer()
amplifier = Amplifier()
lights = Lights()

# Facade
home_theater = HomeTheaterFacade(dvd_player, amplifier, lights)

# Usando a Facade para assistir a um filme
home_theater.assistir_filme("Inception")

# Usando a Facade para desligar o sistema
home_theater.encerrar_filme()
