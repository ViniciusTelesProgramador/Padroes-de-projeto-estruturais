import math

class Calculadora:
    def __init__(self):
        self._valor = 0.0

    def operar(self, valor):
        self._valor = valor
        return self._valor

class CalculadoraDecorator(Calculadora):
    def __init__(self, calculadora, operacao):
        self._calculadora = calculadora
        self._operacao = operacao
        self._resultado_anterior = None

    def operar(self, valor):
        if self._resultado_anterior is None:
            self._resultado_anterior = valor
        else:
            self._resultado_anterior = self._calculadora.operar(self._resultado_anterior)
            
        resultado = self._resultado_anterior
        
        if self._operacao == 'quadrado':
            return resultado ** 2
        elif self._operacao == 'raiz':
            return math.sqrt(resultado)
        elif self._operacao == 'porcentagem':
            return resultado * 0.5  # 50% do valor original
        else:
            return resultado

if __name__ == "__main__":
    valor = 16

    calculadora = Calculadora()
    print(f"Valor inserido: {valor}")

    # Calcular quadrado
    calculadora = CalculadoraDecorator(calculadora, 'quadrado')
    print(f"Quadrado de {valor} = {calculadora.operar(valor)}")

    # Calcular raiz quadrada
    calculadora = CalculadoraDecorator(calculadora, 'raiz')
    print(f"Raiz quadrada de {valor} = {calculadora.operar(valor)}")

    # Calcular 50% do valor original
    calculadora = CalculadoraDecorator(calculadora, 'porcentagem')
    print(f"50% de {valor} = {calculadora.operar(valor)}")
