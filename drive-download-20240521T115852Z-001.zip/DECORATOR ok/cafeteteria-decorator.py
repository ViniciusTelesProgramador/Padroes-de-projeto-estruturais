class Cafe:
    def get_custo(self):
        return 5.0

class CafeDecorator:
    def __init__(self, cafe):
        self._cafe = cafe

    def get_custo(self):
        return self._cafe.get_custo()

class LeiteDecorator(CafeDecorator):
    def get_custo(self):
        return self._cafe.get_custo() + 1.0

class CremeDecorator(CafeDecorator):
    def get_custo(self):
        return self._cafe.get_custo() + 0.5

class XaropeDecorator(CafeDecorator):
    def __init__(self, cafe, custo_extra):
        super().__init__(cafe)
        self._custo_extra = custo_extra

    def get_custo(self):
        return self._cafe.get_custo() + self._custo_extra

if __name__ == "__main__":
    #café básico
    cafe_basico = Cafe()
    print("Café básico: R$", cafe_basico.get_custo())

    #adicionar leite
    cafe_com_leite = LeiteDecorator(cafe_basico)
    print("Café com leite: R$", cafe_com_leite.get_custo())

    #adicionar creme
    cafe_com_creme = CremeDecorator(cafe_basico)
    print("Café com creme: R$", cafe_com_creme.get_custo())

    #adicionar xarope de baunilha
    cafe_com_xarope = XaropeDecorator(cafe_basico, 0.75)
    print("Café com xarope de baunilha: R$", cafe_com_xarope.get_custo())

    #adicionar leite, creme e xarope de caramelo
    cafe_com_tudo = XaropeDecorator(CremeDecorator(LeiteDecorator(cafe_basico)), 1.5)
    print("Café especial: R$", cafe_com_tudo.get_custo())
