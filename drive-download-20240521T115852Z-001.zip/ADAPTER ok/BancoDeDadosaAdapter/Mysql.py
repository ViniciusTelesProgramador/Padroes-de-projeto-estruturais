from conex import conex


class Mysql(conex):
    def conexao(self):
        return "Conectado ao Mysql"
    
