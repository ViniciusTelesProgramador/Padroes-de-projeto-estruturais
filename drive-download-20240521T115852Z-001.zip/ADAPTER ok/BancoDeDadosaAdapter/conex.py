from abc import ABC, abstractmethod

class conex(ABC):
    @abstractmethod
    def conexao(self):
        pass

class Mysql(conex):
    def conexao(self):
        return "Conectado ao Mysql"
