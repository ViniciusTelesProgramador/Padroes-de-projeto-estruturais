from conex import conex


class MongoDB(conex):
    def conexao(self):
        return "Conectado ao MongoDB"