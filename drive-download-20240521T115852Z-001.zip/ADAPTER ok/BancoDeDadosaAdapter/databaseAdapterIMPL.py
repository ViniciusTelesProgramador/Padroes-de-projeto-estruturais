from databaseAdapter import databaseAdapter
from conex import Mysql

class databaseAdapterImpl(databaseAdapter):
    def __init__(self):
        self.BancosDeDados = Mysql()

    def getconex(self):
        return self.BancosDeDados.conexao()

    def desconecta(self):
        return self.BancosDeDados.desconecta()
