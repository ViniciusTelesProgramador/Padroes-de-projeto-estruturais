from conex import conex


class Postgree(conex):
    def conexao(self):
        return "Conectado ao Postgree"