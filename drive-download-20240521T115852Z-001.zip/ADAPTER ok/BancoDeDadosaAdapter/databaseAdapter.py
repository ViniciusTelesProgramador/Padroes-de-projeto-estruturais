from abc import ABC, abstractmethod, ABCMeta


class databaseAdapter(metaclass=ABCMeta):
    @staticmethod
    @abstractmethod
    def getconex(self):
        pass
