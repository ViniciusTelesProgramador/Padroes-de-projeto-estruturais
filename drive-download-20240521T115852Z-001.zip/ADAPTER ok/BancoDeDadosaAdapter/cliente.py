from databaseAdapterIMPL import databaseAdapterImpl
from Mysql import Mysql
from MongoDB import MongoDB
from Postgree import Postgree


#MYSQL
Banco = Mysql()
BancoAdapter = databaseAdapterImpl()

BancoAdapter.BancosDeDados = Banco
print(Banco.conexao())  # Saída: Conectado ao Mysql


#MONGODB
Banco1= MongoDB()
BancoAdapter1 = databaseAdapterImpl()

BancoAdapter1.BancosDeDados = Banco1
print(Banco1.conexao())  # Saída: Conectado ao MongoDB

#POSTGREE
Banco2= Postgree()
BancoAdapter2 = databaseAdapterImpl()

BancoAdapter2.BancosDeDados = Banco2
print(Banco2.conexao())  # Saída: Conectado ao Postgree

